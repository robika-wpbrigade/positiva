$(function(){

	$('.banners-img').slick({ 
	   
	   autoplay: true,
	   infinite: true,
	   speed: 500,
	   fade: true,
	   cssEase: 'linear',
	   arrows:false
		});   
 });
 

$('.slider-box').slick({
 dots:true,
 slidesToShow: 1,
 slidesToScroll: 1,
 cssEase: 'linear'

});
$('.ban-slider').slick({
   dots:true,
   arrows:false,
   slidesToShow: 1,
   slidesToScroll: 1,
   cssEase: 'linear'
 
 });


 $(document).ready(function(){

   $('.menu-toggle').click(function(){
	   
	   $('.menu-links').animate({
		   width: 'toggle',
	   })
	 
   });
});

/*--calendar--*/

$(function(){
   $(".datepicker").datepicker({
	   changeMonth: true,
	   changeYear: true,
	   buttonImage: "./img/calendar.jpg",
	   buttonImageOnly: true,
	   showOn: "both",
   });
});


/*--dropdown-menu--*/
$('ul li').hover(
	function() {
	  $('ul.sub-nav', this).stop().slideDown(200);
	},
	function() {
	  $('ul.sub-nav', this).stop().slideUp(200);
	}
);


/*tabs*/
$(document).ready(function(){

	$('.buttons button').click(function(){
	
		var tab_id= $(this).attr('data-tab')
		$('.buttons button').removeClass('active')
		$('.form-field').removeClass('active')
		$(this).addClass('active')
		$("#" + tab_id).addClass('active')
	
	});
	});

	/*calendar*/
	$(document).ready(function(){

		$('.tabs button').click(function(){
		
			var tab_id= $(this).attr('data-tab')
			$('.tabs button').removeClass('active')
			$('.calendar-field').removeClass('active')
			$(this).addClass('active')
			$("#" + tab_id).addClass('active')
		
		});
		});